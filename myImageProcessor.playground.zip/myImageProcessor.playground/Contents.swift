//: Playground - noun: a place where people can play

import UIKit



class ImageProcessor {
    var defaultFilters = [String: UIImage]()
    var customFilters = [String:UIImage]()
    var myObj: ImageFilter
    
    init() {
        let myImg = UIImage(named: "sample")!
        self.myObj = ImageFilter(iImage: myImg)!
        
        defaultFilters["Contrast_50"] = myObj.setContrast(50)
        defaultFilters["sampleIntensity"] = myObj.setIntensity(100, redTint: 70, greenTint: 60)
        
        defaultFilters["convertToxRay"] = myObj.convertToxRay()
        defaultFilters["removeRed"] = myObj.removeColor("Red")
        defaultFilters["removeBlue"] = myObj.removeColor("Green")
        defaultFilters["removeGreen"] = myObj.removeColor("Blue")
    }
    
    func applyDefaultFilters(filterNames: [String]) -> UIImage {
        
        var finalImage: UIImage
        //initialized to default image - if invalid filter passed then original object returned
        finalImage = myObj.getUIImage(myObj)
        
        for filter in filterNames {
            finalImage = defaultFilters[filter]!
        }
        return finalImage
    }
    
}

//utilizing the interface given above
let processor = ImageProcessor()
let enhanceObj = processor.applyDefaultFilters(["Contrast_50", "sampleIntensity"])

//-------------- ALTERNATE INTERFACE - FUNCTION -------------------//

let myImg = UIImage(named: "sample")!


// creating ImageFilter Object - > for simplicity declared ... can be passed as parameter too

let sampleImg = ImageFilter(iImage: myImg)!


/*
* Function to apply filter with predefined paramters
* Filter Name takes name of filter -> not passing parameters since i am using predefined filters - can be added additional params
* oldOrNew tells us do we need to create a new instance or keep applying filter to old instance
*/
func ApplyPreDefinedFilter(filterName: String, oldOrNew: Int) -> UIImage{

    var myObj: ImageFilter
    
    if(oldOrNew == 0){
        myObj = sampleImg
    }
    else{
         myObj = ImageFilter(iImage: myImg)!
    }
    
    /* Sequence of Filters*/
    if(filterName == "setContrast"){
        return myObj.setContrast(50)
    }else if(filterName == "setIntensity"){
        return myObj.setIntensity(100, redTint: 70, greenTint: 60)
    }else if(filterName == "convertToxRay"){
        return myObj.convertToxRay()
    }else{
        print("Invalid Filter! Returning new/old image whichever was selected as param")
        return myObj.getUIImage(myObj)
    }
    
}


let enhance = ApplyPreDefinedFilter("setContrast", oldOrNew: 0)


let moreFilter = ApplyPreDefinedFilter("setIntensity", oldOrNew: 0)

/* Explicitly applying the filter with a new image to show effect*/
let newFilter = ApplyPreDefinedFilter("setIntensity", oldOrNew: 1)


/* Explicitly applying the filter with a new image to show effect move to sampleImg at the top to get xray*/
let xFilter = ApplyPreDefinedFilter("convertToxRay", oldOrNew: 1)

let wrongFilter = ApplyPreDefinedFilter("noFilter", oldOrNew: 1)
