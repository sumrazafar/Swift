import Foundation
import UIKit

public struct ImageFilter{
    
    public var myImage : RGBAImage
    
    public var avgRed :Int
    public var avgGreen: Int
    public var avgBlue: Int
    public var sum: Int
   
    /* initializer sets the properties of the class*/
    
    public init?(iImage: UIImage){
        myImage = RGBAImage(image: iImage)!
        
        var totalRed = 0;
        var totalGreen = 0;
        var totalBlue = 0;
        
        for y in 0..<myImage.height{
            for x in 0..<myImage.width{
                let index = y * myImage.width + x
                let pixel = myImage.pixels[index]
                
                totalRed += Int(pixel.red)
                totalGreen += Int(pixel.green)
                totalBlue += Int(pixel.blue)
            }
        }
        
        let pixelCount = myImage.width * myImage.height
        
        avgRed = totalRed/pixelCount
        avgGreen = totalGreen/pixelCount
        avgBlue = totalBlue/pixelCount
        sum = avgBlue + avgGreen + avgRed
        
    }
    
    /*
        Gray = (Red * 0.2126 + Green * 0.7152 + Blue * 0.0722)
    */
    public func convertToxRay(RedFactor: Double = 0.2126, GreenFactor: Double = 0.7152, BlueFactor: Double = 0.0722) -> UIImage{
        
        for y in 0..<myImage.height{
            for x in 0..<myImage.width{
                let index = y * myImage.width + x
                var pixel = myImage.pixels[index]
                let red = max(min(255, UInt8(Double(pixel.red) * RedFactor)),0)
                let green = max(min(255, UInt8(Double(pixel.green) * GreenFactor)),0)
                let blue = max(min(255, UInt8(Double(pixel.blue) * BlueFactor)),0)
                pixel.red = 120
                pixel.green = 120
                pixel.blue = 120
                pixel.alpha = max(min(255, UInt8(red + blue + green)),0)
                myImage.pixels[index] = pixel
            }
        }
        
        return myImage.toUIImage()!
    }
    
    public func setContrast(contrast: Int = 10, lowLevelDivisor: Int = 1)-> UIImage{
        
        let factor = (259 * (contrast + 255)) / (255 * (259 - contrast))
        
        for y in 0..<myImage.height{
            for x in 0..<myImage.width{
                let index = y * myImage.width + x
                var pixel = myImage.pixels[index]
                
                if( Int(pixel.red) +  Int(pixel.green) +  Int(pixel.blue) < sum){
                    pixel.red = max(min(255, UInt8((factor/lowLevelDivisor) * Int(pixel.red))),0)
                    pixel.green = max(min(255, UInt8((factor/lowLevelDivisor) * Int(pixel.green))),0)
                    pixel.blue = max(min(255, UInt8((factor/lowLevelDivisor) * Int(pixel.blue))),0)
                }else{
                    pixel.red = max(min(255, UInt8(factor * Int(pixel.red))),0)
                    pixel.green = max(min(255, UInt8(factor * Int(pixel.green))),0)
                    pixel.blue = max(min(255, UInt8(factor * Int(pixel.blue))),0)

                }
                
                myImage.pixels[index] = pixel
            }
        }
        return myImage.toUIImage()!
    }
    
    public func setIntensity(blueTint: Int, redTint: Int, greenTint: Int)-> UIImage{
        
        for y in 0..<myImage.height{
            for x in 0..<myImage.width{
                let index = y * myImage.width + x
                var pixel = myImage.pixels[index]
                
                let redPer = (Int(pixel.red) / 100) * redTint
                let bluePer = (Int(pixel.blue) / 100) * blueTint
                let greenPer = (Int(pixel.green) / 100) * greenTint
                
                pixel.red = max(min(255, UInt8(redPer)),0)
                pixel.green = max(min(255, UInt8(greenPer)),0)
                pixel.blue = max(min(255, UInt8(bluePer)),0)
                
                
                myImage.pixels[index] = pixel
            }
        }
        return myImage.toUIImage()!
    }

    
    public func getUIImage(Obj: ImageFilter) -> UIImage{
        return Obj.myImage.toUIImage()!
    }
    
    public func removeColor(colorToRemove: String) ->UIImage{
        for y in 0..<myImage.height{
            for x in 0..<myImage.width{
                let index = y * myImage.width + x
                var pixel = myImage.pixels[index]
              
                if(colorToRemove == "Red"){
                    pixel.red = 0
                }else if(colorToRemove == "Green"){
                    pixel.green = 0
                }else{
                     pixel.blue = 0
                }
                
                 myImage.pixels[index] = pixel
            }
        }
        return myImage.toUIImage()!

    }
    

}
